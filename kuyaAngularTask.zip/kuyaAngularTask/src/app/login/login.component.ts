import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  //userName: any;
  loginForm: FormGroup;
  isSubmitted = false;

  userList: Array<any> = [
    {
      username: "abcd",
      password: "12345"
    }
  ]

  constructor(private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get formControls() { return this.loginForm.controls; }

  login() {
    console.log(this.loginForm.value);
    this.isSubmitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    localStorage.setItem('test', JSON.stringify(this.loginForm.value));

    for (let i = 0; i < this.userList.length; i++) {
      if (this.loginForm.value.username == this.userList[i]['username'] &&
        this.loginForm.value.password == this.userList[i]['password']) {

        this.router.navigateByUrl('/trainList');
      }
      else {
        this.loginForm.invalid
      }

    }
  }


}
