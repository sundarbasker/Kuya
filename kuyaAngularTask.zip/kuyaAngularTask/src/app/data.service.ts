import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; 
import { environment } from '../environments/environment';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  getList(): Observable<any>{
    //return this.http.get('https://reqres.in/api/users')
 return this.http.get(environment.ListOfTrain)
 .pipe(
     map(result => result)
   );
 }

}
