import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from  '@angular/router';

@Component({
  selector: 'app-list-train',
  templateUrl: './list-train.component.html',
  styleUrls: ['./list-train.component.scss']
})
export class ListTrainComponent implements OnInit {

  users: Object;
  constructor(private data: DataService, private router: Router) { }

  ngOnInit(): void {
    this.data.getList().subscribe(data => {
      this.users = data
      console.log(this.users);
    }
  );
  }

  reservPopup:boolean = true;
  ticketHistory:boolean = true;
  reserveTitle:boolean = true;
  ticketTitle:boolean;

  // tickpopup(){
  //   this.reservPopup = true;
  //   this.reserveTitle = true;
  //   this.ticketHistory = false;
  //   this.ticketTitle = false;
  // }
  count = 0;

  bookTicket() {
    
    var names = (<HTMLInputElement>document.getElementById("name")).value;
    var ages = (<HTMLInputElement>document.getElementById("age")).value;
    var seats = (<HTMLInputElement>document.getElementById("seat")).value;
    this.count += 1;
      
     var name = localStorage.setItem("names", names);
     var age =  localStorage.setItem("ages", ages);
      var seat = localStorage.setItem("seats", seats);
      // localStorage.setItem("count", count);
      console.log(this.count);
      // Retrieve
      this.reservPopup = false;
      this.reserveTitle = false;
      this.ticketHistory = true;
      this.ticketTitle = true;


      var allnode = document.createElement("UL");
      allnode.id = "index"+this.count;

      var nodename = document.createElement("LI");
  var nodeage = document.createElement("LI");
  var nodeseat = document.createElement("LI");
  var cancel = document.createElement("BUTTON");
  cancel.style.color = "#FFF";
  cancel.style.backgroundColor = "#333";
  cancel.style.border = "0px";
  cancel.style.marginTop = "20px";
  cancel.style.padding = "10px";
  cancel.style.cursor = "pointer";
  var cancelli = document.createElement("LI");
  cancelli.style.display = "none";
  cancel.addEventListener("click", function (){
    console.log('clicked');
    this.previousElementSibling.id="ticketCancel"
    cancelli.style.display = "block";
    cancelli.style.color = "red";
    cancelli.style.fontSize = "20px";
    cancelli.style.fontWeight = "bold";
      this.style.display = "none";
      
      
  });
  var hr = document.createElement("hr");
  var textnode = document.createTextNode("Name: " + names);
  var textAge = document.createTextNode("Age: " +ages);
  var textSeat = document.createTextNode("No. of seat: " +seats);
  var textcancel = document.createTextNode("Cancel the ticket?");
  var textcancelli = document.createTextNode("Ticket Cancelled");

  nodename.appendChild(textnode);
  nodeage.appendChild(textAge);
  nodeseat.appendChild(textSeat);
  cancel.appendChild(textcancel);
  cancelli.appendChild(textcancelli);

  allnode.appendChild(nodename);
  allnode.appendChild(nodeage);
  allnode.appendChild(nodeseat);
  allnode.appendChild(cancelli);
  allnode.appendChild(cancel);

  document.getElementById("show").appendChild(allnode);

  document.getElementById("show").appendChild(hr);


      document.getElementById("regName").innerHTML = localStorage.getItem("names");
      document.getElementById("regAge").innerHTML = localStorage.getItem("ages");
      document.getElementById("regSeat").innerHTML = localStorage.getItem("seats");

      document.getElementById("show").style.display = "block";
      document.getElementById("show1").style.display = "block";
      

     // regName = localStorage.getItem("name");
    }

    close(){
      this.reservPopup = true;
      this.reserveTitle = true;
      this.ticketHistory = true;
      this.ticketTitle = true;
      this.router.navigateByUrl('/trainList');
      
      localStorage.setItem("names", "");
      localStorage.setItem("ages", "");
      localStorage.setItem("seats", "");

      document.getElementById("regName").innerHTML = localStorage.getItem("names");
      document.getElementById("regAge").innerHTML = localStorage.getItem("ages");
      document.getElementById("regSeat").innerHTML = localStorage.getItem("seats");
      

      document.getElementById("show").style.display = "none";
      document.getElementById("show1").style.display = "block";

    }
}
